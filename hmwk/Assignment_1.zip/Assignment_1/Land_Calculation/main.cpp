/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Robert
 *
 * Created on September 11, 2016, 10:17 PM
 */

#include <iostream>

using namespace std;

const float acre = 43560;

int main(int argc, char** argv) {

    float land= 3.91876e5f;
    float totAcre= land/acre; //Total Acres
    
    cout<<"The total number of acres is "<<totAcre<<" for a land size of "<<land;
    return 0;
}

