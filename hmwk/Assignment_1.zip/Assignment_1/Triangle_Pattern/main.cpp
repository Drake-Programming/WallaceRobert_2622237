/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Robert
 *
 * Created on September 11, 2016, 7:41 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

   char c = '*';
   char x = ' ';
    
    cout << x<<x<<x<<c<<x<<x<<x<<endl; //   *  
    cout << x<<x<<c<<c<<c<<x<<x<<endl; //  ***
    cout << x<<c<<c<<c<<c<<c<<x<<endl; // *****
    cout << c<<c<<c<<c<<c<<c<<c<<endl; //*******
    return 0;
}

