/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Robert
 *
 * Created on September 11, 2016, 9:06 PM
 */

#include <iostream>

using namespace std;

const unsigned char PERCENT = 100;

int main(int argc, char** argv) {

    unsigned short cstSurv = 16500, //Number of surveys
            cstEnrg, //Energy Drinkers
            cstCitr; //Citrus Energy Drinkers
    unsigned char pEnergy = 15, //Percentage of Energy Drinkers
            pCitrus = 58; //Percentage of Citrus Drinkers
    
    cstEnrg = cstSurv*pEnergy/PERCENT;
    cstCitr = cstEnrg*pCitrus/PERCENT;
    
    cout <<"The number of customers surveyed = "<<cstSurv<<endl;
    cout <<"The percentage of energy drinkers = "<<static_cast<int>(pEnergy)<<endl;
    cout <<"The percentage of citrus energy drinkers = "<<static_cast<int>(pCitrus)<<endl;
    cout <<"The number of energy drinkers = "<<cstEnrg<<endl;
    cout <<"The number of citrus energy drinkers = "<<cstCitr<<endl;
    
    return 0;
}

