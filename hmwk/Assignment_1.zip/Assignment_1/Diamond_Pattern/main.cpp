/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Robert
 *
 * Created on September 11, 2016, 9:29 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    cout    <<"   *   "<<endl
            <<"  ***  "<<endl
            <<" ***** "<<endl
            <<"*******"<<endl
            <<" ***** "<<endl
            <<"  ***  "<<endl
            <<"   *   ";
    
    return 0;
}

