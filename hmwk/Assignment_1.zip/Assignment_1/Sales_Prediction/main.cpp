/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Robert
 *
 * Created on September 11, 2016, 8:33 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    float eastC= 5.8e1f; //East Coast Division Percentage
    float sales= 8.6e6f; //Total Sales
    float eastCS= eastC/100 * sales; //East Coast Sales
    
    cout <<"Total Company Sales Totaled "<<sales<<" million"<<endl;
    cout << "East Coast Division Sales Totaled "<<eastCS<<" million";
    return 0;
}

