/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Robert
 *
 * Created on September 11, 2016, 10:07 PM
 */

#include <iostream>

using namespace std;


int main(int argc, char** argv) {

    float gal= 1.5e1f; //Gallons of fuel
    float mil= 3.75e2f; // Miles
    float mpg= mil/gal; //Miles per gallon

    cout<<"The Miles per Gallon is "<<mpg;
    return 0;
}

