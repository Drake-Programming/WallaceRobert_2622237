/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Robert
 *
 * Created on September 11, 2016, 8:21 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    cout << "Robert Wallace"<<endl
            <<"18812 Alderbrook dr, Riverside, California, 92508"<<endl
            <<"951-536-7621"<<endl
            <<"Computer Science";
    
    return 0;
}

