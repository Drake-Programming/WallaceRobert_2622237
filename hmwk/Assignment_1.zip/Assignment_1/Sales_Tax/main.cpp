/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Robert
 *
 * Created on September 11, 2016, 8:51 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    float pur; //Purchase
    float sT; //Sales Tax
    float cT; //County Tax
    float total; //Total of sale
    
    pur = 95;
    sT = pur * 4/100;
    cT = pur * 2/100;
    total = pur + sT +cT;
    
    cout<<"Base purchase of item was $"<<pur<<endl;
    cout<<"State tax equals to "<<sT<<endl;
    cout<<"County tax equals to "<<cT<<endl;
    cout<<"The total purchase equals to $"<<total;
    
    return 0;
}

