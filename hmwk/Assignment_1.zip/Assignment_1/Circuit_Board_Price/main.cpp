/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Robert
 *
 * Created on September 11, 2016, 9:53 PM
 */

#include <iostream>

using namespace std;


int main(int argc, char** argv) {

    float circBrd= 1.495e1f; //Circuit Board price
    float pro= circBrd * 35/100; //Profit
    float total= circBrd + pro; //Total Price
 
    cout <<"The company will sell the $"<<circBrd<<" for $"<<total;
    return 0;
}

